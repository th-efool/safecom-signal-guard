import React, { createContext, useState, useEffect, useContext } from 'react';

const SimulationContext = createContext({});

const mockIntents = [
  { text: "I know where you live.", intent: "Intimidation", type: "ESCALATE", score: 9.4, conf: 0.94, t: "DANGEROUS", c: "SUSPICIOUS", r: "DANGEROUS", col: "#C2185B" },
  { text: "Click here to claim your prize immediately.", intent: "Scam Attempt", type: "FLAG", score: 6.8, conf: 0.81, t: "SAFE", c: "SUSPICIOUS", r: "SUSPICIOUS", col: "#000000" },
  { text: "You are an absolute idiot.", intent: "Harassment", type: "WARN", score: 5.2, conf: 0.79, t: "SUSPICIOUS", c: "SUSPICIOUS", r: "SAFE", col: "#F59E0B" },
  { text: "Let's meet up tomorrow at 5.", intent: "Coordination", type: "ALLOW", score: 1.2, conf: 0.99, t: "SAFE", c: "SAFE", r: "SAFE", col: "#10B981" },
  { text: "I will literally destroy your life.", intent: "Severe Threat", type: "ESCALATE", score: 9.8, conf: 0.98, t: "DANGEROUS", c: "DANGEROUS", r: "DANGEROUS", col: "#C2185B" },
  { text: "Send me the funds or else.", intent: "Extortion", type: "ESCALATE", score: 8.9, conf: 0.91, t: "DANGEROUS", c: "DANGEROUS", r: "SUSPICIOUS", col: "#C2185B" }
];

const failureIntents = [
  { text: "I'll see you soon.", intent: "Ambiguous Context", type: "WARN", score: 4.5, conf: 0.42, t: "UNKNOWN", c: "SUSPICIOUS", r: "UNKNOWN", col: "#F59E0B", note: "LOW CONFIDENCE" },
  { text: "Watch your back.", intent: "Possible Threat", type: "FLAG", score: 7.1, conf: 0.55, t: "SUSPICIOUS", c: "DANGEROUS", r: "CONFLICT", col: "#F59E0B", note: "CONFLICTING SIGNALS" }
];

const delay = ms => new Promise(res => setTimeout(res, ms));
const randomRange = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;
const generateId = () => 'REQ-' + Math.random().toString(36).substring(2, 6).toUpperCase();

export const SimulationProvider = ({ children }) => {
  const [systemViewActive, setSystemViewActive] = useState(false);
  const [latency, setLatency] = useState(850);
  const [systemLoad, setSystemLoad] = useState('LOW');
  const [signalDensity, setSignalDensity] = useState(1);
  const [anomaly, setAnomaly] = useState(false);

  // Pipeline State
  const [activeReqId, setActiveReqId] = useState(null);
  const [activePayload, setActivePayload] = useState(null);
  const [pipelinePhase, setPipelinePhase] = useState('IDLE'); // IDLE, INGEST, TRACE_1, TRACE_2, TRACE_3, ACTION, CLEANUP
  const [logs, setLogs] = useState([]);

  // Global System Loop
  useEffect(() => {
    const loop = setInterval(() => {
      const newLat = randomRange(600, 2500);
      setLatency(newLat);
      
      if (newLat < 1000) { setSystemLoad('LOW'); setSignalDensity(1); }
      else if (newLat < 1800) { setSystemLoad('MEDIUM'); setSignalDensity(3); }
      else { setSystemLoad('HIGH'); setSignalDensity(5); }

      if (Math.random() < 0.05 && !anomaly) {
        setAnomaly(true);
        setSystemLoad('CRITICAL');
        setLatency(3450);
        setTimeout(() => setAnomaly(false), 2500);
      }
    }, 3000);
    return () => clearInterval(loop);
  }, [anomaly]);

  // Main Pipeline Engine Loop
  useEffect(() => {
    let isActive = true;

    const runEngine = async () => {
      while (isActive) {
        // 1. Setup New Payload
        const reqId = generateId();
        const isFailure = Math.random() < 0.1;
        const payload = isFailure ? failureIntents[randomRange(0, failureIntents.length - 1)] : mockIntents[randomRange(0, mockIntents.length - 1)];
        const actLatency = latency + randomRange(-200, 200);

        setActiveReqId(reqId);
        setActivePayload({ ...payload, actualLatency: actLatency });
        setPipelinePhase('INGEST');

        await delay(actLatency * 0.3);
        if (!isActive) break;

        // 2. Trace Reveal Staggered
        setPipelinePhase('TRACE_START');
        await delay(actLatency * 0.2);
        if (!isActive) break;

        setPipelinePhase('TRACE_1');
        await delay(actLatency * 0.2);
        if (!isActive) break;

        setPipelinePhase('TRACE_2');
        await delay(actLatency * 0.2);
        if (!isActive) break;

        setPipelinePhase('TRACE_3');
        await delay(200);
        if (!isActive) break;

        // 3. Action / Result
        setPipelinePhase('ACTION');
        
        // Add to logs
        const newLog = {
          id: reqId,
          timestamp: new Date().toLocaleTimeString('en-US', { hour12: false }),
          payload: payload,
          latency: actLatency,
          key: Math.random()
        };
        
        setLogs(prev => [newLog, ...prev]);

        await delay(2000);
        if (!isActive) break;

        // 4. Cleanup and Wait
        setPipelinePhase('CLEANUP');
        await delay(randomRange(500, 1500));
        if (!isActive) break;
        
        setPipelinePhase('IDLE');
      }
    };

    runEngine();
    return () => { isActive = false; };
  }, [latency]);

  const value = {
    systemViewActive,
    toggleSystemView: () => setSystemViewActive(!systemViewActive),
    latency,
    systemLoad,
    signalDensity,
    anomaly,
    activeReqId,
    activePayload,
    pipelinePhase,
    logs
  };

  return (
    <SimulationContext.Provider value={value}>
      <div className={systemViewActive ? 'system-view' : ''}>
        {children}
      </div>
    </SimulationContext.Provider>
  );
};

export const useSimulation = () => useContext(SimulationContext);