import React from 'react';
import HeroSection from '../components/HeroSection';
import PipelineSection from '../components/PipelineSection';
import AgentsSection from '../components/AgentsSection';
import PrivacySection from '../components/PrivacySection';

const LandingPage = () => {
  return (
    <>
      <HeroSection />
      <PipelineSection />
      <AgentsSection />
      <PrivacySection />
    </>
  );
};

export default LandingPage;