import React from 'react';

const DashboardPage = () => {
  return (
    <div className="flex-grow flex items-center justify-center p-6 bg-[#fafafa]">
      <div className="w-full max-w-2xl bg-white brutal-border p-12 shadow-[8px_8px_0_0_#000] flex flex-col items-center text-center">
        <iconify-icon icon="solar:server-square-linear" class="text-6xl mb-6 text-[#C2185B]"></iconify-icon>
        <h1 className="font-semibold text-3xl uppercase tracking-tighter mb-4">Dashboard Access Restricted</h1>
        <p className="font-mono text-sm text-black/60 mb-8 max-w-md">
          &gt; SYSTEM AUTHENTICATION REQUIRED.<br/>
          &gt; CONNECTING TO SECURE TELEMETRY STREAM...
        </p>
        <div className="flex items-center gap-3 font-mono text-xs border border-black p-3 bg-black/5">
          <div className="w-2 h-2 bg-[#F59E0B] animate-pulse"></div>
          <span>AWAITING HANDSHAKE</span>
        </div>
      </div>
    </div>
  );
};

export default DashboardPage;