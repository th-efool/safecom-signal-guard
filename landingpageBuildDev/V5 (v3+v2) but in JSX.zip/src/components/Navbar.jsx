import React from 'react';
import { Link } from 'react-router-dom';
import { useSimulation } from '../context/SimulationContext';
import clsx from 'clsx';

const Navbar = () => {
  const { latency, systemLoad, anomaly } = useSimulation();

  return (
    <nav className="fixed top-0 w-full z-50 bg-white/90 backdrop-blur-sm brutal-border-b">
      <div className="flex w-full h-14 pr-6 pl-6 items-center justify-between">
        <div className="flex items-center gap-4">
          <div className={clsx("w-3 h-3 transition-colors", anomaly ? "bg-[#C2185B]" : "bg-[#10B981] node-active")}></div>
          <span className="font-semibold text-lg tracking-tighter uppercase">SafeCom</span>
          <span className="font-mono text-xs text-black/50 ml-4 hidden md:inline-flex items-center gap-4">
            <span>SYS_STATUS: ONLINE</span>
            <span>|</span>
            <span className={clsx(systemLoad === 'CRITICAL' && "text-[#C2185B] font-bold")}>LOAD: {systemLoad}</span>
            <span>|</span>
            <span className={clsx(latency > 2000 && "text-[#F59E0B] font-bold")}>LAT: {latency}ms</span>
          </span>
        </div>
        <div className="flex items-center gap-6 font-mono text-xs uppercase font-medium">
          <Link 
            to="/dashboard"
            className="flex items-center gap-2 bg-black text-white px-4 py-2 hover:bg-[#C2185B] transition-colors"
          >
            <span>Init / Dashboard</span>
            <iconify-icon icon="solar:arrow-right-linear" width="1.2em"></iconify-icon>
          </Link>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;