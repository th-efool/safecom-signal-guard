import React from 'react';
import { useSimulation } from '../context/SimulationContext';
import clsx from 'clsx';

const getAgentColorClass = (val) => {
  if (val === 'DANGEROUS') return 'text-white bg-[#C2185B] px-1 font-bold';
  if (val === 'SUSPICIOUS') return 'text-black bg-[#F59E0B] px-1 font-bold';
  if (val === 'SAFE') return 'text-white bg-[#10B981] px-1 font-bold';
  return 'text-white bg-black px-1 font-bold';
};

const scrambleStr = (str) => {
  if (!str) return '';
  return str.split('').map(() => Math.random() > 0.5 ? '*' : '#').join('');
};

const PipelineSection = () => {
  const { latency, pipelinePhase, activePayload, systemViewActive, activeReqId } = useSimulation();

  // Derived states based on pipelinePhase
  const isIngestActive = pipelinePhase === 'INGEST';
  const isTraceActive = pipelinePhase.startsWith('TRACE');
  const isActionActive = pipelinePhase === 'ACTION' || pipelinePhase === 'CLEANUP';

  // Specific trace states
  const showTD = pipelinePhase === 'TRACE_1' || pipelinePhase === 'TRACE_2' || pipelinePhase === 'TRACE_3' || isActionActive;
  const showCV = pipelinePhase === 'TRACE_2' || pipelinePhase === 'TRACE_3' || isActionActive;
  const showRA = pipelinePhase === 'TRACE_3' || isActionActive;

  return (
    <section id="flow" className="w-full py-24 px-6 lg:px-12 brutal-border-b bg-white relative overflow-hidden">
      <div className="max-w-7xl mx-auto flex flex-col">
        
        <div className="mb-16 flex flex-col md:flex-row md:items-end justify-between gap-8 z-10">
          <div>
            <h2 className="font-semibold text-4xl tracking-tighter uppercase mb-2">Signal Processing Pipeline</h2>
            <p className="font-mono text-sm text-black/60">&gt; TRACING DATA TRAJECTORY FROM INGEST TO ACTION</p>
          </div>
          <div className="font-mono text-xs border border-black px-3 py-1 w-fit flex gap-4 bg-black/5">
            <span>STORAGE: NONE</span>
            <span className="text-black/20">|</span>
            <span>AVG_LATENCY: {latency}ms</span>
          </div>
        </div>

        {/* Flow Diagram */}
        <div className="relative w-full flex flex-col lg:flex-row items-stretch justify-between gap-8 lg:gap-0 mt-8">
          
          {/* Background SVG Connectors (Desktop) */}
          <div className="hidden lg:block absolute top-1/2 left-0 w-full h-px -translate-y-1/2 z-0">
             <svg className="w-full h-24 overflow-visible" preserveAspectRatio="none">
               <path d="M 0 12 L 100% 12" fill="none" stroke="#000" strokeWidth="1" strokeDasharray="2 2"></path>
             </svg>
          </div>

          {/* Step 1: Input */}
          <div className={clsx(
            "relative z-10 w-full lg:w-1/4 bg-white brutal-border p-6 transition-colors duration-300",
            isIngestActive ? "border-black shadow-[4px_4px_0_0_#C2185B]" : "shadow-[4px_4px_0_0_#000]"
          )}>
            <div className="w-8 h-8 bg-black text-white flex items-center justify-center font-mono text-xs mb-4 transition-colors">01</div>
            <h3 className="font-semibold text-xl tracking-tight uppercase mb-4">Raw Ingest</h3>
            <div className={clsx(
              "font-mono text-[10px] bg-black/5 p-2 border border-black/20 text-black/70 mb-4 h-24 overflow-hidden leading-tight scramble-text",
              !isIngestActive && activeReqId ? "decay-fade" : "opacity-100"
            )}>
              {pipelinePhase === 'IDLE' ? '[AWAITING]' : (
                isIngestActive ? (
                  <>&#123;<br/>&nbsp;&nbsp;"id": "{activeReqId}",<br/>&nbsp;&nbsp;"content": "{systemViewActive ? '[0x9A, 0x1B, 0xFF...]' : activePayload?.text}"<br/>&#125;</>
                ) : (
                  <>&#123;<br/>&nbsp;&nbsp;"id": "{activeReqId}",<br/>&nbsp;&nbsp;"content": "{scrambleStr(activePayload?.text)}"<br/>&#125;</>
                )
              )}
            </div>
            <span className="font-mono text-[10px] text-black/60 uppercase flex items-center gap-2">
              <iconify-icon icon="solar:import-linear"></iconify-icon> {isIngestActive ? 'Payload Received' : 'Listening...'}
            </span>
          </div>

          {/* Step 2: Agent Trace */}
          <div className={clsx(
            "relative z-10 w-full lg:w-1/4 brutal-border p-6 transform transition-all duration-300",
            isTraceActive ? "bg-black text-white shadow-[4px_4px_0_0_#C2185B] lg:scale-110" : "bg-white text-black shadow-[4px_4px_0_0_#000] lg:scale-105"
          )}>
            <div className={clsx(
              "absolute -top-3 -right-3 w-6 h-6 flex items-center justify-center transition-colors",
              isTraceActive ? "bg-[#C2185B] node-active" : "bg-black"
            )}>
              <iconify-icon icon="solar:cpu-linear" className="text-white text-xs"></iconify-icon>
            </div>
            <div className={clsx(
              "w-8 h-8 flex items-center justify-center font-mono text-xs mb-4 transition-colors",
              isTraceActive ? "bg-white text-black" : "bg-black text-white"
            )}>02</div>
            <h3 className={clsx(
              "font-semibold text-xl tracking-tight uppercase mb-4 transition-colors",
              isTraceActive ? "text-[#C2185B]" : ""
            )}>Agent Trace</h3>
            <div className="space-y-3 font-mono text-[10px]">
              <div className="flex justify-between items-center border-b border-current/10 pb-1">
                <span className="opacity-60">ThreatDetector</span> 
                <span className={clsx(showTD ? getAgentColorClass(activePayload?.t) : "opacity-30 font-bold", showTD && !activePayload?.t && "text-[#C2185B] animate-pulse")}>
                  {showTD ? (activePayload?.t || 'ANALYZING...') : '---'}
                </span>
              </div>
              <div className="flex justify-between items-center border-b border-current/10 pb-1">
                <span className="opacity-60">ContextValidator</span> 
                <span className={clsx(showCV ? getAgentColorClass(activePayload?.c) : "opacity-30 font-bold", showCV && !activePayload?.c && "text-[#C2185B] animate-pulse")}>
                  {showCV ? (activePayload?.c || 'ANALYZING...') : '---'}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="opacity-60">RiskAnalyzer</span> 
                <span className={clsx(showRA ? getAgentColorClass(activePayload?.r) : "opacity-30 font-bold", showRA && !activePayload?.r && "text-[#C2185B] animate-pulse")}>
                  {showRA ? (activePayload?.r || 'ANALYZING...') : '---'}
                </span>
              </div>
            </div>
          </div>

          {/* Step 3: Action Engine */}
          <div className={clsx(
            "relative z-10 w-full lg:w-1/4 bg-white brutal-border p-6 transition-colors duration-300",
            isActionActive ? "border-[#C2185B] shadow-[4px_4px_0_0_#C2185B]" : "shadow-[4px_4px_0_0_#000]"
          )}>
            <div className="w-8 h-8 bg-black text-white flex items-center justify-center font-mono text-xs mb-4 transition-colors">03</div>
            <h3 className="font-semibold text-xl tracking-tight uppercase mb-4">Action Engine</h3>
            <div className="flex gap-2 mb-4 h-5">
              {isActionActive && activePayload ? (
                <>
                  <span className="text-white px-2 py-0.5 font-mono text-[10px] uppercase" style={{ backgroundColor: activePayload.col }}>{activePayload.type}</span>
                  <span className="border border-black px-2 py-0.5 font-mono text-[10px] uppercase">{Math.round(activePayload.conf * 100)}% CONF</span>
                </>
              ) : (
                <span className="bg-black/10 text-black px-2 py-0.5 font-mono text-[10px] uppercase hidden">--</span>
              )}
            </div>
            <div className="font-mono text-[10px] bg-black/5 p-2 border border-black/20 text-black/70 space-y-1">
              <div className="flex justify-between"><span>Intent:</span> <span className="text-black">{isActionActive ? activePayload?.intent : '--'}</span></div>
              <div className="flex justify-between"><span>Score:</span> <span className="font-bold" style={{ color: isActionActive ? activePayload?.col : 'inherit' }}>{isActionActive ? `${activePayload?.score}/10` : '--'}</span></div>
              <div className="flex justify-between"><span>Latency:</span> <span>{isActionActive ? `${activePayload?.actualLatency}ms` : '--'}</span></div>
            </div>
          </div>

          {/* Step 4: Platform */}
          <div className="relative z-10 w-full lg:w-1/4 bg-white brutal-border p-6 border-dashed group hover:border-solid hover:bg-black hover:text-white transition-all duration-300 cursor-pointer">
            <div className="w-8 h-8 border border-black flex items-center justify-center font-mono text-xs mb-4 group-hover:border-white transition-colors">04</div>
            <h3 className="font-semibold text-xl tracking-tight uppercase mb-4">Platform Route</h3>
            <div className="font-mono text-xs space-y-3 opacity-60 group-hover:opacity-100 transition-opacity">
              <div className="flex items-center justify-between"><span className="flex items-center gap-2"><iconify-icon icon="solar:shield-check-linear"></iconify-icon> ALLOW</span> <span className="text-[10px]">Pass</span></div>
              <div className="flex items-center justify-between"><span className="flex items-center gap-2"><iconify-icon icon="solar:flag-linear"></iconify-icon> FLAG</span> <span className="text-[10px]">Review</span></div>
              <div className="flex items-center justify-between"><span className="flex items-center gap-2"><iconify-icon icon="solar:user-block-linear"></iconify-icon> ESCALATE</span> <span className="text-[10px]">Block</span></div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};

export default PipelineSection;