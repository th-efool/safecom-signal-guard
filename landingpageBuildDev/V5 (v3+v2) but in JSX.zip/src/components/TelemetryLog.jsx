import React, { useState, useEffect } from 'react';
import { useSimulation } from '../context/SimulationContext';
import clsx from 'clsx';

const LogItem = ({ log, systemViewActive }) => {
  const [expanded, setExpanded] = useState(false);
  const [decayed, setDecayed] = useState(false);

  // Auto decay logic matching the "Zero Storage Proof" 12s lifecycle
  useEffect(() => {
    const timer1 = setTimeout(() => {
      setDecayed(true);
    }, 10000); // Start fade slightly early
    
    return () => clearTimeout(timer1);
  }, []);

  if (decayed) return null; // Removed from DOM after decay animation completes in parent via wrapper

  const { payload } = log;
  const badgeStyle = payload.type === 'ESCALATE' 
    ? 'bg-[#C2185B] text-white border border-[#C2185B]' 
    : (payload.type === 'WARN' || payload.type === 'FLAG') 
      ? `bg-transparent border border-current text-current`
      : 'bg-black text-white border border-black';

  return (
    <div 
      className={clsx(
        "flex flex-col border-b border-black/10 pb-2 mb-3 cursor-pointer group hover:bg-black/5 p-2 transition-all duration-500 decay-item",
        expanded ? "trace-expanded" : "",
        decayed ? "decay-fade" : "opacity-100"
      )}
      onClick={() => setExpanded(!expanded)}
    >
      <div className="flex justify-between items-center mb-1">
        <span style={{ color: payload.col }} className="font-semibold text-[10px]">[{log.timestamp}] {log.id}</span>
        <div className="flex items-center text-[10px]">
          {payload.note && (
            <span className="bg-[#F59E0B] text-black px-1 font-bold text-[8px] ml-2 animate-pulse">{payload.note}</span>
          )}
          <span className={clsx("px-1 py-0.5 ml-2 font-bold", badgeStyle)} style={badgeStyle.includes('transparent') ? { color: payload.col, backgroundColor: `${payload.col}10` } : {}}>
            {systemViewActive ? `ACT:${payload.type}` : payload.type}
          </span>
        </div>
      </div>
      <span className="text-black/80 text-[10px]">Intent: {payload.intent}</span>
      
      {/* Expanded Trace Details */}
      <div className="expandable-trace w-full">
        <div className="mt-2 pt-2 border-t border-black/10 text-[9px] text-black/60 space-y-1">
          <div className="flex justify-between">
            <span>→ ThreatDetector:</span> 
            {systemViewActive ? <span className="font-bold text-black">{payload.conf.toFixed(2)}</span> : <span>{payload.t}</span>}
          </div>
          <div className="flex justify-between">
            <span>→ ContextValidator:</span> 
            {systemViewActive ? <span className="font-bold text-black">{(payload.conf*0.8).toFixed(2)}</span> : <span>{payload.c}</span>}
          </div>
          <div className="flex justify-between">
            <span>→ RiskAnalyzer:</span> 
            {systemViewActive ? <span className="font-bold text-black">{(payload.conf*1.1).toFixed(2)}</span> : <span>{payload.r}</span>}
          </div>
        </div>
      </div>

      <div className="flex gap-4 text-black/50 mt-1 text-[9px]">
        <span>Conf: {Math.round(payload.conf*100)}%</span>
        <span>Lat: {log.latency}ms</span>
      </div>
    </div>
  );
};

const TelemetryLog = () => {
  const { logs, systemViewActive } = useSimulation();
  
  // Keep only the most recent 6 logs to prevent DOM bloat
  const visibleLogs = logs.slice(0, 6);

  return (
    <div className="p-3 font-mono text-[10px] h-64 overflow-hidden bg-[#fafafa] relative flex flex-col">
      {visibleLogs.map((log) => (
        <LogItem key={log.key} log={log} systemViewActive={systemViewActive} />
      ))}
      {visibleLogs.length === 0 && (
        <div className="text-black/30 flex h-full items-center justify-center uppercase italic">
          Waiting for telemetry...
        </div>
      )}
    </div>
  );
};

export default TelemetryLog;