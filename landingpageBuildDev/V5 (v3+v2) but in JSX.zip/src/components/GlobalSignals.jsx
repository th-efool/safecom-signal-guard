import React, { useMemo } from 'react';
import { useSimulation } from '../context/SimulationContext';
import clsx from 'clsx';

const GlobalSignals = () => {
  const { signalDensity, anomaly } = useSimulation();

  const signals = useMemo(() => {
    const count = signalDensity * 2;
    const arr = [];
    for (let i = 0; i < count; i++) {
      const isX = Math.random() > 0.5;
      arr.push({
        id: i,
        isX,
        opacity: Math.floor(Math.random() * (70 - 30 + 1)) + 30,
        pos1: Math.floor(Math.random() * (90 - 10 + 1)) + 10,
        size: Math.floor(Math.random() * (400 - 100 + 1)) + 100,
        delay: Math.floor(Math.random() * 1000)
      });
    }
    return arr;
  }, [signalDensity]);

  return (
    <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden mix-blend-multiply" style={{ '--anim-speed': `${3 / signalDensity}s` }}>
      {signals.map((sig) => (
        <div
          key={sig.id}
          className={clsx(`opacity-${sig.opacity}`, sig.isX ? 'signal-line-x' : 'signal-line-y')}
          style={{
            top: sig.isX ? `${sig.pos1}vh` : undefined,
            width: sig.isX ? `${sig.size}px` : undefined,
            left: !sig.isX ? `${sig.pos1}vw` : undefined,
            height: !sig.isX ? `${sig.size}px` : undefined,
            animationDelay: `${sig.delay}ms`,
            background: anomaly ? 'linear-gradient(90deg, transparent, #F59E0B, transparent)' : undefined
          }}
        />
      ))}
    </div>
  );
};

export default GlobalSignals;