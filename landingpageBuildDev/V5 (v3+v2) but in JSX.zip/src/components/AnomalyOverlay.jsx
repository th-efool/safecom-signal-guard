import React from 'react';
import { useSimulation } from '../context/SimulationContext';
import clsx from 'clsx';

const AnomalyOverlay = () => {
  const { anomaly } = useSimulation();

  return (
    <div className={clsx(
      "fixed inset-0 pointer-events-none z-40 bg-[#C2185B]/10 mix-blend-multiply flex items-center justify-center transition-opacity duration-200",
      anomaly ? "opacity-100" : "opacity-0 hidden"
    )}>
      <div className="border-4 border-[#C2185B] bg-white px-8 py-4 font-mono font-bold text-[#C2185B] text-4xl uppercase glitch-active flex flex-col items-center">
        <span>ANOMALY DETECTED</span>
        <span className="text-xs mt-2 text-black animate-blink">PRIORITY OVERRIDE / ESCALATION FORCED</span>
      </div>
    </div>
  );
};

export default AnomalyOverlay;