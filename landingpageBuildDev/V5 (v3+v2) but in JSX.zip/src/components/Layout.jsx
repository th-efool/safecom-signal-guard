import React from 'react';
import Navbar from './Navbar';
import GlobalSignals from './GlobalSignals';
import AnomalyOverlay from './AnomalyOverlay';
import clsx from 'clsx';
import { useSimulation } from '../context/SimulationContext';

const Layout = ({ children }) => {
  const { anomaly } = useSimulation();

  return (
    <div className={clsx("relative min-h-screen text-base selection:bg-[#C2185B] selection:text-white flex flex-col transition-colors duration-300", anomaly && "anomaly-flash")}>
      {/* Background Grids & Layers */}
      <div className="fixed inset-0 pointer-events-none z-0 system-grid opacity-50"></div>
      <GlobalSignals />
      <AnomalyOverlay />
      
      <Navbar />
      
      <main className="relative z-10 flex-grow flex flex-col pt-14">
        {children}
      </main>
    </div>
  );
};

export default Layout;