import React, { useEffect, useState } from 'react';
import { useSimulation } from '../context/SimulationContext';
import RightPanels from './RightPanels';
import clsx from 'clsx';

const scrambleStr = (str) => {
  if (!str) return '';
  return str.split('').map(() => Math.random() > 0.5 ? '*' : '#').join('');
};

const HeroSection = () => {
  const { systemViewActive, activeReqId, activePayload, pipelinePhase } = useSimulation();
  
  const [memContent, setMemContent] = useState('[AWAITING_PAYLOAD]');
  const [scrambledContent, setScrambledContent] = useState('');

  // Determine memory state based on pipeline phase
  const isWriting = pipelinePhase === 'INGEST';
  const isFlushed = pipelinePhase !== 'IDLE' && pipelinePhase !== 'INGEST';

  useEffect(() => {
    if (pipelinePhase === 'INGEST' && activePayload) {
      setScrambledContent(scrambleStr(activePayload.text));
    }
  }, [pipelinePhase, activePayload]);

  return (
    <section className="relative w-full min-h-[90vh] flex flex-col justify-center px-6 lg:px-12 brutal-border-b">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center h-full pt-12 pb-24">
        
        {/* Left text content */}
        <div className="lg:col-span-7 flex flex-col z-10 items-start">
          <div className="flex items-center gap-2 font-mono text-xs uppercase border border-black px-2 py-1 mb-8 bg-white shadow-[2px_2px_0_0_#000]">
            <div className="w-1.5 h-1.5 bg-[#C2185B] animate-blink"></div>
            <span>Agent Tracing Active</span>
          </div>
          
          <h1 className="font-semibold text-5xl md:text-7xl lg:text-8xl tracking-tighter leading-[0.95] uppercase mb-8">
            Harm doesn't wait.<br/>
            <span className="text-[#C2185B]">Detection</span> shouldn't either.
          </h1>
          
          <p className="font-mono text-sm max-w-xl text-black/70 mb-12 border-l-2 border-black pl-4 py-1 leading-relaxed relative overflow-hidden group">
            &gt; MULTI-AGENT ARCHITECTURE INITIALIZED.<br/>
            &gt; TRACE: DETECTOR → VALIDATOR → ANALYZER.<br/>
            {systemViewActive && (
              <>
                <span className="text-[#C2185B] block">&gt; MEM_BUFFER_ADDR: 0x8F9A2</span>
                <span className="text-[#C2185B] block">&gt; PIPELINE_MODE: ASYNC_STAGGERED</span>
              </>
            )}
          </p>
          
          <div className="flex flex-col gap-2 w-full max-w-md">
            {/* Memory Buffer (Zero Storage Proof) */}
            <div className="w-full border border-black bg-black/5 p-3 font-mono text-[10px] uppercase">
              <div className="flex justify-between items-center mb-2 border-b border-black/20 pb-1">
                <span className="text-black/50">VOLATILE_MEMORY_BUFFER</span>
                <span className={clsx(
                  "px-1 transition-colors",
                  isWriting ? "bg-[#C2185B] text-white font-bold animate-pulse" : 
                  isFlushed ? "bg-black text-white" : "bg-black text-white"
                )}>
                  {isWriting ? "WRITING" : isFlushed ? "FLUSHED" : "IDLE"}
                </span>
              </div>
              <div className={clsx(
                "h-12 overflow-hidden text-black/70 scramble-text transition-opacity duration-300",
                isFlushed ? "decay-fade" : "opacity-100"
              )}>
                {pipelinePhase === 'IDLE' && '[AWAITING_PAYLOAD]'}
                {pipelinePhase !== 'IDLE' && activeReqId && (
                  <div>
                    &#123;<br/>
                    &nbsp;&nbsp;"id": "{activeReqId}",<br/>
                    &nbsp;&nbsp;"content": "
                    {isWriting && !systemViewActive && <span className="text-black">{activePayload?.text}</span>}
                    {isWriting && systemViewActive && <span className="text-[#C2185B]">[0x9A, 0x1B, 0xFF...]</span>}
                    {isFlushed && <span className="text-black/50">{scrambledContent}</span>}
                    "<br/>
                    &#125;
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Right floating system visuals */}
        <RightPanels />

      </div>
      
      {/* Bottom marquee/ticker */}
      <div className="absolute bottom-0 left-0 w-full brutal-border-t bg-black text-white h-8 flex items-center overflow-hidden whitespace-nowrap font-mono text-xs uppercase z-20">
        <div className="flex ticker-wrap">
          <div className="flex-1 flex justify-around">
            <span className="mx-4 text-[#C2185B]">///</span> TRACE DETECTOR ACTIVE 
            <span className="mx-4 text-[#C2185B]">///</span> CONTEXT VALIDATION 
            <span className="mx-4 text-[#C2185B]">///</span> RISK ANALYSIS RUNNING 
            <span className="mx-4 text-[#C2185B]">///</span> ESCALATION THRESHOLD MET 
            <span className="mx-4 text-[#C2185B]">///</span> IN-MEMORY PROCESSING
          </div>
          <div className="flex-1 flex justify-around" aria-hidden="true">
            <span className="mx-4 text-[#C2185B]">///</span> TRACE DETECTOR ACTIVE 
            <span className="mx-4 text-[#C2185B]">///</span> CONTEXT VALIDATION 
            <span className="mx-4 text-[#C2185B]">///</span> RISK ANALYSIS RUNNING 
            <span className="mx-4 text-[#C2185B]">///</span> ESCALATION THRESHOLD MET 
            <span className="mx-4 text-[#C2185B]">///</span> IN-MEMORY PROCESSING
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;