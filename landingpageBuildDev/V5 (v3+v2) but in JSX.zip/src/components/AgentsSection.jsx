import React from 'react';

const AgentsSection = () => {
  return (
    <section id="agents" className="w-full py-24 px-6 lg:px-12 brutal-border-b bg-[#FAFAFA] relative overflow-hidden">
      <div className="max-w-7xl mx-auto flex flex-col">
        <div className="mb-16 flex flex-col md:flex-row md:items-end justify-between gap-8">
          <div>
            <h2 className="font-semibold text-4xl tracking-tighter uppercase mb-2">Multi-Agent Swarm</h2>
            <p className="font-mono text-sm text-black/60">&gt; DISTRIBUTED ANALYSIS FOR ZERO-LATENCY VERDICTS</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-0 brutal-border bg-white shadow-[4px_4px_0_0_#000]">
          {/* Agent 1 */}
          <div className="p-8 brutal-border-r brutal-border-b md:brutal-border-b-0 hover:bg-black hover:text-white transition-colors group cursor-default">
            <div className="flex justify-between items-start mb-12">
              <div className="w-10 h-10 bg-black text-white group-hover:bg-white group-hover:text-black flex items-center justify-center font-mono text-sm transition-colors">01</div>
              <iconify-icon icon="solar:radar-linear" class="text-3xl text-black/20 group-hover:text-white/40"></iconify-icon>
            </div>
            <h3 className="font-semibold text-2xl tracking-tight uppercase mb-4">Threat<br/>Detector</h3>
            <p className="font-mono text-xs opacity-70 leading-relaxed">
              Frontline pattern recognition. Scans raw payload for immediate structural and semantic threats before deep processing.
            </p>
          </div>

          {/* Agent 2 */}
          <div className="p-8 brutal-border-r brutal-border-b md:brutal-border-b-0 hover:bg-black hover:text-white transition-colors group cursor-default">
            <div className="flex justify-between items-start mb-12">
              <div className="w-10 h-10 bg-black text-white group-hover:bg-white group-hover:text-black flex items-center justify-center font-mono text-sm transition-colors">02</div>
              <iconify-icon icon="solar:brain-linear" class="text-3xl text-black/20 group-hover:text-white/40"></iconify-icon>
            </div>
            <h3 className="font-semibold text-2xl tracking-tight uppercase mb-4">Context<br/>Validator</h3>
            <p className="font-mono text-xs opacity-70 leading-relaxed">
              Nuance engine. Evaluates ambiguous signals against conversational history and behavioral baselines to prevent false positives.
            </p>
          </div>

          {/* Agent 3 */}
          <div className="p-8 hover:bg-[#C2185B] hover:text-white transition-colors group cursor-default">
            <div className="flex justify-between items-start mb-12">
              <div className="w-10 h-10 bg-black text-white flex items-center justify-center font-mono text-sm">03</div>
              <iconify-icon icon="solar:shield-warning-linear" class="text-3xl text-black/20 group-hover:text-white/40"></iconify-icon>
            </div>
            <h3 className="font-semibold text-2xl tracking-tight uppercase mb-4">Risk<br/>Analyzer</h3>
            <p className="font-mono text-xs opacity-70 leading-relaxed">
              Final verdict synthesizer. Aggregates agent confidence scores and triggers policy-based actions (ALLOW, FLAG, ESCALATE).
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AgentsSection;