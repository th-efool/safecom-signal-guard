import React from 'react';
import { useSimulation } from '../context/SimulationContext';
import TelemetryLog from './TelemetryLog';
import clsx from 'clsx';

const RightPanels = () => {
  const { activeReqId, activePayload, pipelinePhase } = useSimulation();

  const isActionPhase = pipelinePhase === 'ACTION' || pipelinePhase === 'CLEANUP';
  const showVerdict = isActionPhase && activePayload;

  const panelColor = showVerdict ? activePayload.col : '#C2185B';
  const verdictType = showVerdict ? activePayload.type : 'AWAITING';
  const score = showVerdict ? activePayload.score.toFixed(1) : '--';

  const getBarClass = (type, target) => {
    if (!showVerdict) return 'bg-black/20';
    return type === target ? 'node-active' : 'bg-black/20';
  };

  const getLabelClass = (type, target) => {
    if (!showVerdict) return 'text-black/50';
    return type === target ? 'font-semibold' : 'text-black/50';
  };

  return (
    <div className="lg:col-span-5 relative h-full min-h-[450px] w-full hidden md:block">
      
      {/* System Panel 1: Live Event Stream */}
      <div className="absolute top-0 right-0 w-80 bg-white brutal-border shadow-[4px_4px_0_0_#000] z-20">
        <div className="brutal-border-b bg-black text-white font-mono text-[10px] p-2 flex justify-between uppercase">
          <span>Live_Telemetry_Log</span>
          <span className="animate-blink">_</span>
        </div>
        <TelemetryLog />
      </div>

      {/* System Panel 2: Action Engine Focus */}
      <div 
        className="absolute top-64 left-4 w-64 bg-white brutal-border z-30 transition-all duration-300"
        style={{ borderColor: panelColor, boxShadow: `4px 4px 0 0 ${panelColor}` }}
      >
        <div 
          className="border-b font-mono text-[10px] p-2 flex justify-between uppercase transition-colors duration-300 text-white"
          style={{ backgroundColor: panelColor, borderColor: panelColor }}
        >
          <span>Action_Engine</span>
          <span>{showVerdict ? `REQ: ${activeReqId}` : 'AWAITING'}</span>
        </div>
        
        <div className="p-4 flex flex-col w-full relative overflow-hidden">
          {/* Awaiting Overlay */}
          <div className={clsx(
            "absolute inset-0 bg-white/90 backdrop-blur-sm z-10 flex items-center justify-center font-mono text-[10px] uppercase font-bold transition-opacity duration-300",
            showVerdict ? "opacity-0 pointer-events-none" : "opacity-100 text-[#C2185B]"
          )}>
            AWAITING SIGNAL...
          </div>

          <div className="flex justify-between items-end mb-2">
            <span className="font-mono text-[10px] uppercase text-black/60">Threat Score</span>
            <span 
              className="px-2 py-0.5 font-mono text-[10px] font-semibold uppercase"
              style={{ color: panelColor, backgroundColor: `${panelColor}20` }}
            >
              {showVerdict ? verdictType : '---'}
            </span>
          </div>
          
          <div className="flex items-baseline gap-1 mb-4">
            <span className="font-semibold text-5xl tracking-tighter" style={{ color: panelColor }}>{score}</span>
            <span className="font-mono text-[10px] text-black/50">/10</span>
          </div>

          {/* Action State Bar */}
          <div className="flex gap-1 h-1.5 w-full mb-4">
            <div className={clsx("h-full w-1/4 transition-colors", getBarClass(verdictType, 'ALLOW'))} style={{ backgroundColor: verdictType === 'ALLOW' ? panelColor : undefined }}></div>
            <div className={clsx("h-full w-1/4 transition-colors", getBarClass(verdictType, 'WARN'))} style={{ backgroundColor: verdictType === 'WARN' ? panelColor : undefined }}></div>
            <div className={clsx("h-full w-1/4 transition-colors", getBarClass(verdictType, 'FLAG'))} style={{ backgroundColor: verdictType === 'FLAG' ? panelColor : undefined }}></div>
            <div className={clsx("h-full w-1/4 transition-colors", getBarClass(verdictType, 'ESCALATE'))} style={{ backgroundColor: verdictType === 'ESCALATE' ? panelColor : undefined }}></div>
          </div>

          <div className="grid grid-cols-4 gap-1 text-[8px] font-mono text-center mb-4">
            <span className={clsx("transition-colors", getLabelClass(verdictType, 'ALLOW'))} style={{ color: verdictType === 'ALLOW' ? panelColor : undefined }}>ALLOW</span>
            <span className={clsx("transition-colors", getLabelClass(verdictType, 'WARN'))} style={{ color: verdictType === 'WARN' ? panelColor : undefined }}>WARN</span>
            <span className={clsx("transition-colors", getLabelClass(verdictType, 'FLAG'))} style={{ color: verdictType === 'FLAG' ? panelColor : undefined }}>FLAG</span>
            <span className={clsx("transition-colors", getLabelClass(verdictType, 'ESCALATE'))} style={{ color: verdictType === 'ESCALATE' ? panelColor : undefined }}>ESCALATE</span>
          </div>

        </div>
      </div>

      {/* Connecting Lines in UI */}
      <svg className="absolute inset-0 w-full h-full pointer-events-none z-10" style={{ overflow: 'visible' }}>
        <path 
          d="M 280 80 L 132 80 L 132 240" 
          fill="none" 
          stroke={showVerdict ? panelColor : '#000'} 
          strokeWidth="1" 
          strokeDasharray="4 4" 
          className={clsx("transition-colors", showVerdict && "node-active")}
        ></path>
        <circle 
          cx="132" 
          cy="240" 
          r="3" 
          fill={showVerdict ? panelColor : '#000'} 
          className={clsx("transition-colors", showVerdict && "node-active")}
        ></circle>
      </svg>

    </div>
  );
};

export default RightPanels;