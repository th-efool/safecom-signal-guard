import React from 'react';

const PrivacySection = () => {
  return (
    <section id="privacy" className="w-full py-24 px-6 lg:px-12 brutal-border-b bg-black text-white relative overflow-hidden">
      <div className="fixed inset-0 pointer-events-none z-0 system-grid opacity-10" style={{ backgroundImage: 'linear-gradient(to right, rgba(255,255,255,0.1) 1px, transparent 1px), linear-gradient(to bottom, rgba(255,255,255,0.1) 1px, transparent 1px)' }}></div>
      <div className="max-w-7xl mx-auto flex flex-col lg:flex-row items-center gap-16 relative z-10">
        
        <div className="lg:w-1/2 flex flex-col items-start">
          <div className="flex items-center gap-2 font-mono text-xs uppercase border border-white/20 px-2 py-1 mb-8">
            <iconify-icon icon="solar:shield-keyhole-linear" class="text-[#10B981]"></iconify-icon>
            <span className="text-[#10B981]">Zero Storage Proof</span>
          </div>
          
          <h2 className="font-semibold text-5xl md:text-6xl tracking-tighter uppercase mb-6">
            We analyze.<br/>We don't store.
          </h2>
          
          <p className="font-mono text-sm text-white/60 mb-8 leading-relaxed max-w-md">
            SafeCom operates exclusively in volatile memory. Payloads are ingested, scored, and immediately flushed from the buffer upon action execution. 
          </p>

          <div className="flex flex-col gap-4 font-mono text-xs w-full max-w-md">
            <div className="flex justify-between border-b border-white/20 pb-2">
              <span className="opacity-50">Database Logs</span>
              <span className="text-[#10B981]">0 BYTES</span>
            </div>
            <div className="flex justify-between border-b border-white/20 pb-2">
              <span className="opacity-50">PII Retention</span>
              <span className="text-[#10B981]">FALSE</span>
            </div>
            <div className="flex justify-between pb-2">
              <span className="opacity-50">Memory Lifecycle</span>
              <span className="text-white">~1200ms (THEN FLUSHED)</span>
            </div>
          </div>
        </div>

        <div className="lg:w-1/2 w-full">
          <div className="border border-white/20 bg-black/50 backdrop-blur-sm p-6 font-mono text-[10px] text-white/50 relative">
            <div className="absolute top-0 right-0 bg-white/10 px-2 py-1 text-white/80 border-b border-l border-white/20">MEM_DUMP_VIZ</div>
            <div className="space-y-2 mt-4">
              <div className="text-[#C2185B]">0x00A1: [ALLOCATING BUFFER]</div>
              <div>0x00A2: INGEST REQ-8F92</div>
              <div>0x00A3: SCORE -&gt; 9.4 (ESCALATE)</div>
              <div>0x00A4: DISPATCH WEBHOOK</div>
              <div className="text-[#10B981] animate-pulse">0x00A5: [FLUSHING BUFFER] // ZEROED</div>
              <div className="text-white/20 pt-2 border-t border-white/10 mt-2">
                00 00 00 00 00 00 00 00 00 00 00 00<br/>
                00 00 00 00 00 00 00 00 00 00 00 00<br/>
                00 00 00 00 00 00 00 00 00 00 00 00
              </div>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};

export default PrivacySection;